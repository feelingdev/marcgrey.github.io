function setAction(clickableObject) {
    var elementClass = clickableObject.attr('class');
    switch (elementClass) {
        case 'optionclose':
            funcOptionClose(clickableObject);
            break;
        case 'footeritem':
            funcFooterItem(clickableObject);
            break;
        case 'pokemon':
            funcPokemon(clickableObject, 0);
            break;
        case 'batterybar':
            funcPokemon(clickableObject, 1);
            break;
        case 'contentitemvalue':
            funcSetValue(clickableObject);
            break;
        case 'footersave':
            funcSave(clickableObject);
            break;
        case 'donatebtn centerx':
            funcDonate(clickableObject);
            break;
        case 'donatebtn centerx restorebtn':
            funcRestore(clickableObject);
            break;
        case 'negativevalue':
            funcNegative(clickableObject);
            break;
        default:
            console.log('Not Found');
            break;
    }
}

function funcOptionClose(clickableObject) {
    $(clickableObject).unbind('click').on('click', function () {

        var pkmnScale = $(mainPokemon).attr('data-scale');

        var pkmnLeft = $(mainPokemon).attr('data-left');

        var pkmnTop = $(mainPokemon).attr('data-top');

        $(mainPokemon).css({
            'top': pkmnTop + 'px',
            'left': pkmnLeft + 'px',
            '-webkit-transform': 'scale(' + pkmnScale + ') translateZ(0)',
            '-moz-transform': 'scale(' + pkmnScale + ') translateZ(0)',
            '-o-transform': 'scale(' + pkmnScale + ') translateZ(0)',
            'transform': 'scale(' + pkmnScale + ') translateZ(0)'
        });

        $(mainPokemon).attr({
            'data-newscale': '',
            'data-newleft': '',
            'data-newtop': ''
        });

        var batteryScale = $(battBar).attr('data-scale');

        var batteryLeft = $(battBar).attr('data-left');

        var batteryTop = $(battBar).attr('data-top');

        $(battBar).css({
            'top': batteryTop + 'px',
            'left': batteryLeft + 'px',
            '-webkit-transform': 'scale(' + batteryScale + ') translateZ(0)',
            '-moz-transform': 'scale(' + batteryScale + ') translateZ(0)',
            '-o-transform': 'scale(' + batteryScale + ') translateZ(0)',
            'transform': 'scale(' + batteryScale + ') translateZ(0)'
        });

        $(battBar).attr({
            'data-newscale': '',
            'data-newleft': '',
            'data-newtop': ''
        });

        hideOption();
    });
}

function funcFooterItem(clickableObject) {
    $(clickableObject).unbind('click').on('click', function (e) {
        e.preventDefault();
        if ($(clickableObject).index() === 0) {
            $(footerOptions).children().css('color', '');
            $(svgPkmn).find('path').attr('fill', 'rgba(51,108,189,1)');
        }
        else {
            $(svgPkmn).find('path').attr('fill', '#AAA');
            $(footerOptions).children().css('color', '');
            $(this).css('color', 'rgba(51,108,189,1)');
        }
        $(contentPointer).css('left', parseInt($(contentPointer).css('width')) * $(this).index() + 'px');
        $(contentPage).css('left', '-' + parseInt($(contentPage).css('width')) / $(contentPage).children().length * $(this).index() + 'px');
    });
}

function funcPokemon(clickableObject, pageNo) {
    $(clickableObject).unbind('touchstart').on('touchstart', function (e) {

        a = setInterval(function () {
            b = b + 1;
            if (b > 3) {
                clearCount();
                showOption(pageNo);
            }
        }, 500);

    }).unbind('touchend').on('touchend', function (e) {
        clearCount();
    });
}

function funcSetValue(clickableObject) {
    $(clickableObject).parent().unbind('click').on('click', function (e) {
        var currentInputValue = '';
        e.preventDefault();
        $(clickableObject).blur();
        $(optionPanel).css('opacity', '0');
        $(optionPanel).css('bottom', '');
        var genericBoxClass = $('.genericbox');
        if ($(genericBoxClass).length === 0) {
            var targetClasses = ['genericbox'];
            genericBox = $(div).clone();
            initElements($(genericBox), targetClasses, $(option));

            targetClasses = ['negativevalue'];
            negativeValue = $(div).clone();
            initElements($(negativeValue), targetClasses, $(genericBox));

setAction($(negativeValue));

            targetClasses = ['itemicon','centerxy','fa','fa-minus-square'];
            negativeIcon = $(div).clone();
            initElements($(negativeIcon), targetClasses, $(negativeValue));

            targetClasses = ['currentvalue'];
            currentValue = $(inputNumber).clone();
            initElements($(currentValue), targetClasses, $(genericBox));

            targetClasses = ['genericcontrol'];
            genericControl = $(div).clone();
            initElements($(genericControl), targetClasses, $(option));

            targetClasses = ['currentlabelholder'];
            currentLabelHolder = $(div).clone();
            initElements($(currentLabelHolder), targetClasses, $(genericControl));

            targetClasses = ['currentlabel', 'centerxy'];
            doneBtn = $(span).clone();
            initElements($(doneBtn), targetClasses, $(currentLabelHolder));
            $(doneBtn).text('DONE');
        }

        setTimeout(function () {
            var thisCurrLabel = $(clickableObject).attr('data-adjustelem') === 'pokemon' ? name + '\'s ' + $(clickableObject).attr('placeholder') : 'Battery\'s ' + $(clickableObject).attr('placeholder');
            $(currentLabel).text(thisCurrLabel);
            $(genericBox).css('top', '40px');
            $(genericControl).css('bottom', '40px');
            setTimeout(function () {

if($(clickableObject).val().indexOf('-') > -1)
{
$(negativeValue).css('color','rgba(51,108,189,1)');
$(negativeValue).attr('data-value','-1');
}
else
{
$(negativeValue).css('color','');
$(negativeValue).attr('data-value','1');
}
                $(currentValue).val($(clickableObject).val().split("-").join(""));

                $(currentLabelHolder).unbind('click').on('click', function () {
                    $(genericBox).css('top', '');
                    $(genericControl).css('bottom', '');
                    setTimeout(function () {
                        $(optionPanel).css('bottom', '50px');
                        $(optionPanel).css('opacity', '1');
                    }, 300);
                });



                $(currentValue).unbind('keyup').on('keyup', function (e) {

                        $(clickableObject).val($(currentValue).val()).trigger('change');

                    $(currentValue).blur();

                    var searchInput = $(currentValue);
                    var strLength = searchInput.val().length * 2;
                    searchInput.focus();
              searchInput[0].setSelectionRange(strLength, strLength);

                });
                $(currentValue).focus();
            }, 300);
        }, 100);
    });

    $(clickableObject).unbind('change').on('change', function () {
        var adjustElem = $(clickableObject).attr('data-adjustelem');
        var adjustType = $(clickableObject).attr('data-adjusttype');

        var currElem = adjustElem === 'pokemon' ? $(mainPokemon) : $(battBar);
        if (adjustType === 'zoom') {

 if ($(clickableObject).val().split(" ").join(" ").length == 0 || isNaN($(clickableObject).val()))
{
$(clickableObject).val($(currElem).attr('data-scale'));
}
else
{
$(clickableObject).val($(clickableObject).val() * parseInt($(negativeValue).attr('data-value')));
}

            $(currElem).attr('data-newscale', parseFloat($(clickableObject).val()));
            $(currElem).css(
                {
                    '-webkit-transform': 'scale(' + $(clickableObject).val() + ') translateZ(0)',
                    '-moz-transform': 'scale(' + $(clickableObject).val() + ') translateZ(0)',
                    '-o-transform': 'scale(' + $(clickableObject).val() + ') translateZ(0)',
                    'transform': 'scale(' + $(clickableObject).val() + ') translateZ(0)'
                });

        }
        else if (adjustType === 'horizontal') {

if ($(clickableObject).val().split(" ").join(" ").length == 0 || isNaN($(clickableObject).val()))
{
$(clickableObject).val($(currElem).attr('data-left'));
}
else
{
$(clickableObject).val($(clickableObject).val() * parseInt($(negativeValue).attr('data-value')));
}

            $(currElem).attr('data-newleft', parseFloat($(clickableObject).val()));
            $(currElem).css('left', $(clickableObject).val() + 'px');
        }
        else if (adjustType === 'vertical') {

if ($(clickableObject).val().split(" ").join(" ").length == 0 || isNaN($(clickableObject).val()))
{
$(clickableObject).val($(currElem).attr('data-top'));
}
else
{
$(clickableObject).val($(clickableObject).val() * parseInt($(negativeValue).attr('data-value')));
}

            $(currElem).attr('data-newtop', parseFloat($(clickableObject).val()));
            $(currElem).css('top', $(clickableObject).val() + 'px');
        }

    });
}

function funcSave(clickableObject) {
    $(clickableObject).unbind('click').on('click', function () {

        if (!isNaN(parseFloat($(mainPokemon).attr('data-newscale')))) {
            $(mainPokemon).attr('data-scale', parseFloat($(mainPokemon).attr('data-newscale')));
        }

        if (!isNaN(parseFloat($(mainPokemon).attr('data-newleft')))) {
            $(mainPokemon).attr('data-left', parseFloat($(mainPokemon).attr('data-newleft')));
        }

        if (!isNaN(parseFloat($(mainPokemon).attr('data-newtop')))) {
            $(mainPokemon).attr('data-top', parseFloat($(mainPokemon).attr('data-newtop')));
        }

        var pokemonScale = parseFloat($(mainPokemon).attr('data-scale'));
        var pokemonLeft = parseFloat($(mainPokemon).attr('data-left'));
        var pokemonTop = parseFloat($(mainPokemon).attr('data-top'));

        Cookies.set(name + 'pokemonScale', pokemonScale, { expires: 500 });

        Cookies.set(name + 'pokemonLeft', pokemonLeft, { expires: 500 });

        Cookies.set(name + 'pokemonTop', pokemonTop, { expires: 500 });

        if (!isNaN(parseFloat($(battBar).attr('data-newscale')))) {
            $(battBar).attr('data-scale', parseFloat($(battBar).attr('data-newscale')));
        }

        if (!isNaN(parseFloat($(battBar).attr('data-newleft')))) {
            $(battBar).attr('data-left', parseFloat($(battBar).attr('data-newleft')));
        }

        if (!isNaN(parseFloat($(battBar).attr('data-newtop')))) {
            $(battBar).attr('data-top', parseFloat($(battBar).attr('data-newtop')));
        }

        var batteryScale = parseFloat($(battBar).attr('data-scale'));
        var batteryLeft = parseFloat($(battBar).attr('data-left'));
        var batteryTop = parseFloat($(battBar).attr('data-top'));

        Cookies.set(name + 'batteryScale', batteryScale, { expires: 500 });

        Cookies.set(name + 'batteryLeft', batteryLeft, { expires: 500 });

        Cookies.set(name + 'batteryTop', batteryTop, { expires: 500 });

        $(optionClose).click();
        savingMessage();

    });
}

function funcDonate(clickableObject) {
    $(clickableObject).unbind('click').on('click', function () {

var tempBox = $(inputText).clone();
$(tempBox).appendTo($(main));
$(tempBox).val(lockScreenNote).select();
document.execCommand("copy");
$(tempBox).remove();

        window.location = 'xeninfo:openurl:' + lockScreenNote;
    });
}

function funcRestore(clickableObject) {
    $(clickableObject).unbind('click').on('click', function () {

        $(mainPokemon).attr({
            'data-newscale': parseFloat(spriteDefaultScale),
            'data-newleft': parseFloat(spriteDefaultLeft),
            'data-newtop': parseFloat(spriteDefaultTop)
        });

        $(battBar).attr({
            'data-newscale': parseFloat(batteryDefaultScale),
            'data-newleft': deviceWidth / 2 - parseInt($(battBar).css('width')) / 2,
            'data-newtop': deviceHeight / 2 - parseInt($(battBar).css('height')) / 2 + parseInt(spriteHeight) / 2 + 10
        });

        $(footerSave).click();
    });
}

function funcNegative(clickableObject)
{
$(clickableObject).unbind('click').on('click', function () {
var currNegValue = $(clickableObject).attr('data-value');
if(parseInt(currNegValue) === 1)
{
$(clickableObject).css('color','rgba(51,108,189,1)');
$(clickableObject).attr('data-value','-1');
}
else
{
$(clickableObject).css('color','');
$(clickableObject).attr('data-value','1');
}

$(clickableObject).parent().children().eq(1).val($(clickableObject).parent().children().eq(1).val()).trigger('keyup');
});
}