var deviceWidth = $(window).innerWidth();
var deviceHeight = $(window).innerHeight();
var name = 'Rotom';
var spriteWidth = '378px';
var spriteHeight = '260px';
var spriteTotalWidth = '38178px';
var spriteDefaultLeft = deviceWidth / 2 - parseInt(spriteWidth) / 2;
var spriteDefaultTop = deviceHeight / 2 - parseInt(spriteHeight) / 2;
var spriteDefaultScale = '1';
var batteryDefaultScale = '1';
var spriteDefaultSpeed = '2.5';
var spriteStep = '100';
var trainerTipText = 'TRAINER TIP:<br/><br/>Set ' + name + ' on Foreground.<br/><br/>While on Lockscreen, Tap and hold ' + name + ' or the Battery for about 5 seconds to adjust Position & Size.<br/><br/>This tip will not visible on lockscreen.<br/><br/>Click the CHECK button below to continue.';
var mainDefaultScale = '0.9';
var savingMessageText = 'Now saving your settings...<br />Don\'t unlock your device as long as this message is visible...';
var paypalMessage = 'Donate via PayPal';
var lockScreenNote = 'paypal.me/geraldalzaga';
var restoreMessage = 'Click to Continue';
var restoreNote = 'This action cannot be undone.';
var lockScreenNote2 = 'This button does not work on lockscreen<br/>with passcode enabled.';
var initDone = 0;
var footerOptionData = [
    ['0', name, 'fa-arrows'],
    ['1', 'Battery', 'fa-battery-three-quarters'],
    ['2', 'Restore Default', 'fa-undo'],
    ['3', 'Buy Me A Beer', 'fa-beer']
];
var positionOptions = [
    ['0','fa-search'],
    ['1','fa-arrows-h'],
    ['2','fa-arrows-v']
];
