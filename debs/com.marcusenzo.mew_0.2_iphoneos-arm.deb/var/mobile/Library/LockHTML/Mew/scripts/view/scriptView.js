var main = $('.main'), body = $('body'), svgPkmn = $('svg');
var mainPokemon;
var battBar, battHealth, battName, battery, battInner, battCharge, batteryBar, mainBatt;
var instruction, innerInstruction, innerBG, trainerTip;
var option, optionPanel, optionContent, footerOptions, footerSave, saveBtn;
var footerItem, positionIcon;
var optionClose, closeBtn, contentPage, contentItem, contentHeader, contentBody;
var contentPointer, contentBodyItem, contentItemIconHolder, contentItemIcon;
var contentItemValue, genericBox, currentValue, genericControl, currentLabel;
var currentLabelHolder, doneBtn, donateBtn;
var paypalIconHolder, paypalIcon;
var paypalTextHolder, paypalText, paypalLink, lockNote;
var restoreBtn, restoreTextNote, restoreIconHolder, restoreIcon, restoreTextHolder, restoreText;
var negativeValue, negativeIcon;
var a;
var b = 0;

function initElements(targetObject, targetClass, targetElement) {
    for (var i = 0; i < targetClass.length; i++) {
        $(targetObject).addClass(targetClass[i]);
    }
    $(targetObject).appendTo(targetElement);
}
function clearCount() {
    clearInterval(a);
    b = 0;
}
function hideOption() {
    $(optionPanel).css('bottom', '');
    setTimeout(function () {
        $(option).css('opacity', '');
        setTimeout(function () {
            $(option).css('display', '');
        }, 100);
    }, 300);
}
function showOption(pageNo) {
    var optionClass = $('.option');
    if ($(optionClass).length === 0) {
        var targetClasses = ['option'];
        option = $(div).clone();
        initElements($(option), targetClasses, $(body));

        targetClasses = ['optionpanel'];
        optionPanel = $(div).clone();
        initElements($(optionPanel), targetClasses, $(option));

        targetClasses = ['optioncontent'];
        optionContent = $(div).clone();
        initElements($(optionContent), targetClasses, $(optionPanel));

        targetClasses = ['contentpointer'];
        contentPointer = $(div).clone();
        initElements($(contentPointer), targetClasses, $(optionContent));

        targetClasses = ['contentpage'];
        contentPage = $(div).clone();
        initElements($(contentPage), targetClasses, $(optionContent));

        for (var i = 0; i < footerOptionData.length; i++) {
            targetClasses = ['contentitem'];
            contentItem = $(div).clone();
            initElements($(contentItem), targetClasses, $(contentPage));

            targetClasses = ['contentheader'];
            contentHeader = $(div).clone();
            initElements($(contentHeader), targetClasses, $(contentItem));

            targetClasses = ['contentheadertitle', 'centery'];
            contentHeaderTitle = $(span).clone();
            initElements($(contentHeaderTitle), targetClasses, $(contentHeader));
            $(contentHeaderTitle).text(footerOptionData[i][1]);

            targetClasses = ['contentbody'];
            contentBody = $(div).clone();
            initElements($(contentBody), targetClasses, $(contentItem));

            if (i < footerOptionData.length - 2) {
                for (var x = 0; x < positionOptions.length; x++) {
                    targetClasses = ['contentbodyitem'];
                    contentBodyItem = $(div).clone();
                    initElements($(contentBodyItem), targetClasses, $(contentBody));

                    targetClasses = ['contentitemiconholder'];
                    contentItemIconHolder = $(div).clone();
                    initElements($(contentItemIconHolder), targetClasses, $(contentBodyItem));

                    targetClasses = ['itemicon', 'fa', positionOptions[x][1], 'centerxy'];
                    contentItemIcon = $(div).clone();
                    initElements($(contentItemIcon), targetClasses, $(contentItemIconHolder));

                    targetClasses = ['contentitemvalue'];
                    contentItemValue = $(inputText).clone();
                    initElements($(contentItemValue), targetClasses, $(contentBodyItem));
                    setAction($(contentItemValue));
                    $(contentItemValue).prop('disabled', true);
                    var thisAdjustElem = i === 0 ? 'pokemon' : 'battery';
                    $(contentItemValue).attr('data-adjustelem', thisAdjustElem);

                    if (x === 0) {
                        $(contentItemValue).attr('data-adjusttype', 'zoom');
                        $(contentItemValue).attr('placeholder', 'Size');
                    }
                    else if (x === 1) {
                        $(contentItemValue).attr('data-adjusttype', 'horizontal');
                        $(contentItemValue).attr('placeholder', 'X-Position');
                    }
                    else if (x === 2) {
                        $(contentItemValue).attr('data-adjusttype', 'vertical');
                        $(contentItemValue).attr('placeholder', 'Y-Position');
                    }
                }
            }
            else if (i === footerOptionData.length - 1) {

                targetClasses = ['donatebtn', 'centerx'];
                donateBtn = $(div).clone();
                initElements($(donateBtn), targetClasses, $(contentBody));

                targetClasses = ['paypallink', 'centerx'];
                paypalLink = $(div).clone();
                initElements($(paypalLink), targetClasses, $(donateBtn));
                $(paypalLink).html(lockScreenNote);

                targetClasses = ['paypallink', 'centerx'];
                lockNote = $(div).clone();
                initElements($(lockNote), targetClasses, $(donateBtn));
                $(lockNote).html(lockScreenNote2);
                $(lockNote).css('top', '-40px');

                targetClasses = ['paypaliconholder'];
                paypalIconHolder = $(div).clone();
                initElements($(paypalIconHolder), targetClasses, $(donateBtn));

                targetClasses = ['itemicon', 'centerxy', 'fa', 'fa-paypal'];
                paypalIcon = $(div).clone();
                initElements($(paypalIcon), targetClasses, $(paypalIconHolder));

                targetClasses = ['paypaltextholder'];
                paypalTextHolder = $(div).clone();
                initElements($(paypalTextHolder), targetClasses, $(donateBtn));

                targetClasses = ['paypaltext', 'centerxy'];
                paypalText = $(span).clone();
                initElements($(paypalText), targetClasses, $(paypalTextHolder));
                $(paypalText).text(paypalMessage);


                setAction($(donateBtn));
            }

            else if (i === footerOptionData.length - 2) {

                targetClasses = ['donatebtn', 'centerx', 'restorebtn'];
                restoreBtn = $(div).clone();
                initElements($(restoreBtn), targetClasses, $(contentBody));

                targetClasses = ['paypallink', 'centerx'];
                restoreTextNote = $(div).clone();
                initElements($(restoreTextNote), targetClasses, $(restoreBtn));
                $(restoreTextNote).html(restoreNote);
                $(restoreTextNote).css('top', '-40px');



                targetClasses = ['paypaliconholder'];
                restoreIconHolder = $(div).clone();
                initElements($(restoreIconHolder), targetClasses, $(restoreBtn));

                targetClasses = ['itemicon', 'centerxy', 'fa', 'fa-undo'];
                restoreIcon = $(div).clone();
                initElements($(restoreIcon), targetClasses, $(restoreIconHolder));

                targetClasses = ['paypaltextholder'];
                restoreTextHolder = $(div).clone();
                initElements($(restoreTextHolder), targetClasses, $(restoreBtn));

                targetClasses = ['paypaltext', 'centerxy'];
                restoreText = $(span).clone();
                initElements($(restoreText), targetClasses, $(restoreTextHolder));
                $(restoreText).text(restoreMessage);

                setAction($(restoreBtn));
            }
        }

        targetClasses = ['optionclose'];
        optionClose = $(div).clone();
        initElements($(optionClose), targetClasses, $(optionContent));

        setAction($(optionClose));

        targetClasses = ['fa', 'fa-close', 'centerxy', 'itemicon'];
        closeBtn = $(div).clone();
        initElements($(closeBtn), targetClasses, $(optionClose));

        targetClasses = ['footeroptions'];
        footerOptions = $(div).clone();
        initElements($(footerOptions), targetClasses, $(optionPanel));

        for (i = 0; i < footerOptionData.length; i++) {
            targetClasses = ['footeritem'];
            footerItem = $(div).clone();
            initElements($(footerItem), targetClasses, $(footerOptions));

            if (i === 0) {
                $(svgPkmn).appendTo($(footerItem));
                $(svgPkmn).css('display', 'block');
                $(svgPkmn).find('path').attr('fill', 'rgba(51,108,189,1)');
            }
            else {
                targetClasses = ['fa', footerOptionData[i][2], 'centerxy', 'itemicon'];
                positionIcon = $(div).clone();
                initElements($(positionIcon), targetClasses, $(footerItem));
            }

            if (i === 0) {
                $(footerItem).css('color', 'rgba(51,108,189,1)');
            }
            setAction($(footerItem));
        }

        targetClasses = ['footersave'];
        footerSave = $(div).clone();
        initElements($(footerSave), targetClasses, $(footerOptions));

        setAction($(footerSave));

        targetClasses = ['fa', 'fa-save', 'centerxy', 'itemicon'];
        saveBtn = $(div).clone();
        initElements($(saveBtn), targetClasses, $(footerSave));
    }

    for (var y = 0; y < $(contentPage).children().length; y++) {
        if (y !== $(contentPage).children().length - 1) {
            var thisContentBody = $(contentPage).children().eq(y).children().eq(1);

            for (var z = 0; z < $(thisContentBody).children().length; z++) {
                if (z === 0) {
                    var thisCurrScale = y === 0 ? $(mainPokemon).attr('data-scale') : $(battBar).attr('data-scale');
                    $(thisContentBody).children().eq(z).children().eq(1).val(thisCurrScale);
                }
                else if (z === 1) {
                    var thisCurrLeftElemen = y === 0 ? mainPokemon : battBar;
                    $(thisContentBody).children().eq(z).children().eq(1).val(parseFloat($(thisCurrLeftElemen).attr('data-left')));
                }
                else if (z === 2) {
                    var thisCurrTopElemen = y === 0 ? mainPokemon : battBar;
                    $(thisContentBody).children().eq(z).children().eq(1).val(parseFloat($(thisCurrLeftElemen).attr('data-top')));
                }
            }
        }
    }

    $(option).css('display', 'block');
    setTimeout(function () {
        $(option).css('opacity', '1');
        setTimeout(function () {
            $(optionPanel).css('bottom', '50px');
        }, 300);
    }, 100);

    $(footerOptions).children().eq(pageNo).click();
}

function initPokemon() {
    var targetClasses = ['pokemon'];
    mainPokemon = $(div).clone();
    initElements($(mainPokemon), targetClasses, $(main));

    var pkmnScale = spriteDefaultScale;
    if (!isNaN(parseFloat(Cookies.get(name + 'pokemonScale')))) {
        pkmnScale = parseFloat(Cookies.get(name + 'pokemonScale'));
    }
    var pkmnLeft = spriteDefaultLeft;
    if (!isNaN(parseFloat(Cookies.get(name + 'pokemonLeft')))) {
        pkmnLeft = parseFloat(Cookies.get(name + 'pokemonLeft'));
    }
    var pkmnTop = spriteDefaultTop;
    if (!isNaN(parseFloat(Cookies.get(name + 'pokemonTop')))) {
        pkmnTop = parseFloat(Cookies.get(name + 'pokemonTop'));
    }

    var a = '';
    for (var i = 0; i < sprite.length; i++) {
        a += sprite[i].split("").reverse().join("");
    }
    var imgurl = 'data:image/png;base64,' + a;

    $(mainPokemon).css({
        'width': spriteWidth,
        'height': spriteHeight,
        'top': pkmnTop + 'px',
        'left': pkmnLeft + 'px',
        'background-size': spriteTotalWidth + ' ' + spriteHeight,
        'background-image': 'url("' + imgurl + '")',
        '-webkit-transform': 'scale(' + pkmnScale + ') translateZ(0)',
        '-moz-transform': 'scale(' + pkmnScale + ') translateZ(0)',
        '-o-transform': 'scale(' + pkmnScale + ') translateZ(0)',
        'transform': 'scale(' + pkmnScale + ') translateZ(0)',
        '-webkit-animation': 'idlepokemon ' + spriteDefaultSpeed + 's steps(' + spriteStep + ') infinite',
        '-moz-animation': 'idlepokemon ' + spriteDefaultSpeed + 's steps(' + spriteStep + ') infinite',
        '-o-animation': 'idlepokemon ' + spriteDefaultSpeed + 's steps(' + spriteStep + ') infinite',
        'animation': 'idlepokemon ' + spriteDefaultSpeed + 's steps(' + spriteStep + ') infinite'
    });

    $(mainPokemon).attr({
        'data-scale': pkmnScale,
        'data-left': parseFloat($(mainPokemon).css('left')),
        'data-top': parseFloat($(mainPokemon).css('top'))
    });

    setAction($(mainPokemon));
}

function initBattery() {
    var targetClasses = ['batterybar'];
    battBar = $(div).clone();
    initElements($(battBar), targetClasses, $(main));

    targetClasses = ['health'];
    battHealth = $(div).clone();
    initElements($(battHealth), targetClasses, $(battBar));

    targetClasses = ['name'];
    battName = $(span).clone();
    initElements($(battName), targetClasses, $(battHealth));
    $(battName).text(name);

    targetClasses = ['battery'];
    battery = $(span).clone();
    initElements($(battery), targetClasses, $(battHealth));
    $(battery).text('100 / 100');

    targetClasses = ['inner'];
    battInner = $(div).clone();
    initElements($(battInner), targetClasses, $(battHealth));

    targetClasses = ['fa', 'fa-bolt', 'charge'];
    battCharge = $(div).clone();
    initElements($(battCharge), targetClasses, $(battInner));

    targetClasses = ['bar'];
    batteryBar = $(div).clone();
    initElements($(batteryBar), targetClasses, $(battInner));

    targetClasses = ['mainbatt'];
    mainBatt = $(div).clone();
    initElements($(mainBatt), targetClasses, $(batteryBar));

    var battScale = batteryDefaultScale;
    if (!isNaN(parseFloat(Cookies.get(name + 'batteryScale')))) {
        battScale = parseFloat(Cookies.get(name + 'batteryScale'));
    }
    var battLeft = deviceWidth / 2 - parseInt($(battBar).css('width')) / 2;
    if (!isNaN(parseFloat(Cookies.get(name + 'batteryLeft')))) {
        battLeft = parseFloat(Cookies.get(name + 'batteryLeft'));
    }
    var battTop = deviceHeight / 2 - parseInt($(battBar).css('height')) / 2 + parseInt(spriteHeight) / 2 + 10;
    if (!isNaN(parseFloat(Cookies.get(name + 'batteryTop')))) {
        battTop = parseFloat(Cookies.get(name + 'batteryTop'));
    }

    $(battBar).css({
        'top': battTop + 'px',
        'left': battLeft + 'px',
        '-webkit-transform': 'scale(' + battScale + ') translateZ(0)',
        '-moz-transform': 'scale(' + battScale + ') translateZ(0)',
        '-o-transform': 'scale(' + battScale + ') translateZ(0)',
        'transform': 'scale(' + battScale + ') translateZ(0)'
    });

    $(battBar).attr({
        'data-scale': battScale,
        'data-left': parseFloat($(battBar).css('left')),
        'data-top': parseFloat($(battBar).css('top'))
    });

    setAction($(battBar));
}

function initInstruction() {
    var targetClasses = ['instruction'];
    instruction = $(div).clone();
    initElements($(instruction), targetClasses, $(body));
    $(instruction).css('display', 'none');

    targetClasses = ['inner'];
    innerInstruction = $(div).clone();
    initElements($(innerInstruction), targetClasses, $(instruction));

    targetClasses = ['innerbg'];
    innerBG = $(div).clone();
    initElements($(innerBG), targetClasses, $(instruction));

    targetClasses = ['trainertip'];
    trainerTip = $(div).clone();
    initElements($(trainerTip), targetClasses, $(innerInstruction));
    $(trainerTip).html(trainerTipText);

    setTimeout(function () {
        $(instruction).css('display', '');
    }, 1000);
}

function savingMessage() {
    if ($(savingMessage).length !== null) {
        $(savingMessage).remove();
    }

    var savingMessage, innerSavingMessage, innerSavingBG, savingText;

    var targetClasses = ['instruction'];
    savingMessage = $(div).clone();
    initElements($(savingMessage), targetClasses, $(body));

    targetClasses = ['inner'];
    innerSavingMessage = $(div).clone();
    initElements($(innerSavingMessage), targetClasses, $(savingMessage));

    targetClasses = ['innerbg'];
    innerSavingBG = $(div).clone();
    initElements($(innerSavingBG), targetClasses, $(savingMessage));

    targetClasses = ['trainertip'];
    savingText = $(div).clone();
    initElements($(savingText), targetClasses, $(innerSavingMessage));
    $(savingText).html(savingMessageText);

    setTimeout(function () {
        $(savingMessage).remove();
    }, 10000);
}

function initKeyFrame() {
    var style = $('<style type="text/css"></style>');
    var keyFrames = '\
    @-webkit-keyframes idlepokemon {\
    0% {\
        background-position: 0 0;\
    }\
    100% {\
        background-position: A_DYNAMIC_VALUEpx 0;\
    }\
    @-moz-keyframes idlepokemon {\
    0% {\
        background-position: 0 0;\
    }\
    100% {\
        background-position: A_DYNAMIC_VALUEpx 0;\
    }\
    @-o-keyframes idlepokemon {\
    0% {\
        background-position: 0 0;\
    }\
    100% {\
        background-position: A_DYNAMIC_VALUEpx 0;\
    }\
    @keyframes idlepokemon {\
    0% {\
        background-position: 0 0;\
    }\
    100% {\
        background-position: A_DYNAMIC_VALUEpx 0;\
    }\
    ';
    $(style).html(keyFrames.replace(/A_DYNAMIC_VALUE/g, '-' + (parseInt(spriteTotalWidth) - parseInt(spriteWidth))));
    $(style).appendTo($('head'));
}

$(document).ready(function () {

initInstruction();
initKeyFrame();
initPokemon();
initBattery();

    $(body).unbind('touchmove').on('touchmove', function (e) {
        e.preventDefault();
    });
    $(body).unbind('contextmenu').on('contextmenu', function (e) {
        e.preventDefault();
    });
    $(option).unbind('touchmove').on('touchmove', function (e) {
        if ($(e.target).hasClass('option')) {
            e.preventDefault();
        }
    }).unbind('touchstart').on('touchstart', function (e) {
        if ($(e.target).hasClass('option')) {
            e.preventDefault();
        }
    });
});

function mainUpdate(type) {

 if ($(instruction).length !== null)
{
        $(instruction).remove();
    }
    
    if (type === 'battery') {

        $(battery).html(batteryPercent + ' / 100');
        $(mainBatt).css('width', batteryPercent + '%');
        if (parseInt(batteryPercent) <= 20) {
            $(mainBatt).removeClass('good');
            $(mainBatt).addClass('bad');
        }
        else {
            $(mainBatt).removeClass('bad');
            $(mainBatt).addClass('good');
        }

        $(battCharge).css('color', '');
        if (batteryCharging) {
            $(battCharge).css('color', '#FFF65A');
        }
    }
}