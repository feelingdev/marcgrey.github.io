var div = $('<div></div>');
var span = $('<span></span>');
var button = $('<button />');
var inputText = $('<input type="text" />');
var inputNumber = $('<input type="tel" />');