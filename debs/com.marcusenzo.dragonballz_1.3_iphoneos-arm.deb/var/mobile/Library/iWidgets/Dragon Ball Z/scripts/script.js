var datespan = $('.date');
var timespan = $('.time');
var battspan = $('.battery');
var temperaturespan = $('.temperature');
var weatherspan = $('.weather');
var artistnsongspan = $('.artistnsong');
var playbtn = $('.playbtn');
var forwardbtn = $('.forwardbtn');
var backwardbtn = $('.backwardbtn');
var container = $('.container');
var option = $('.option');
var optionpanel = $(option).find('.optionpanel');
var togglebutton = $('.togglebutton');
var savingmessage = $('.savingmessage');


var months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

var today = new Date();
var dd = today.getDate();
var mm = months[today.getMonth()];
var yyyy = today.getFullYear();
var hour = today.getHours();
var min = today.getMinutes();

var a;
var b = 0;

function clearCount()
{
        clearInterval(a);
        b = 0;
}

function showOption()
{
    $(option).css('display','block');
    setTimeout(function ()
    {
        $(option).css('opacity','1');
        setTimeout(function ()
        {
            $(optionpanel).css('top','0');
        },300);
    },10);
}

function hideOption()
{
    $(optionpanel).css('top','-100%');
    setTimeout(function ()
    {
        $(option).css('opacity','0');
        setTimeout(function ()
        {
            $(option).css('display','none');
        },300);
    },300);
}

function saveCookie(w)
{
     $(savingmessage).css('display','block');
     if(Cookies.get('theme') != null)
     {
           Cookies.remove('theme'); 
           Cookies.set('theme',w,{ expires : 500 });
      }
      else
      {
            Cookies.set('theme',w,{ expires : 500 });
      }
      setTimeout(function ()
      {
          $(savingmessage).css('display','');
      }, 15000);
}

function changeTheme(i)
{
     saveCookie(themeIt(i));
}

function themeIt(i)
{
    var w = parseInt(i);
          if(w == 0)
          {
                $(togglebutton).attr('data-mode','1');
                $(togglebutton).css('left','32px');
                $(container).removeClass('white');
                $(container).addClass('black');
                return w;
          }
          else
          {
                $(togglebutton).attr('data-mode','0');
                $(togglebutton).css('left','2px');
                $(container).removeClass('black');
                $(container).addClass('white');
                return w;
          }
}

$(document).ready(function ()
{
        var w = $(window).innerWidth();
        var h =  $(window).innerHeight();
        var css = 'styles/' + w + 'x' + h + '.css';
        $('<link/>', {
                rel: 'stylesheet',
                type: 'text/css',
                href: css
        }).appendTo('head');

        $('.credit').text('ORIGINALLY MADE FOR ANDROID BY: u/InputShoryu. PORTED TO IOS BY: u/marcusenzo');

        $(container).unbind('touchstart').on('touchstart', function (e)
{
    if($(e.target).hasClass('container'))
    {
        a = setInterval(function ()
        {
                b = b + 1;
                 if(b > 3)
                {
                    clearCount();
                    showOption();
                }
        }, 500);
    }
});

$(container).unbind('touchend').on('touchend', function ()
{
    if(a)
    {
        clearCount();
    }
});

$(option).unbind('click touchstart').on('click touchstart', function (e)
{
    if($(e.target).hasClass('option'))
    {
        hideOption();
    }
});

if(Cookies.get('theme') != null)
{
    var x = parseInt(Cookies.get('theme'));
    themeIt(x);
}
});

function mainUpdate(type)
{
         today = new Date();
         dd = today.getDate();
         mm = months[today.getMonth()];
         yyyy = today.getFullYear();
         hour = today.getHours();
         min = today.getMinutes();
         if(hour < 10) { hour = '0' + hour; }
         if(min < 10) { min = '0' + min; }
         var date = mm + '<br/>' + dd + ',<br/>' + yyyy;
         var time = hour + ':' + min;
         $(datespan).html(date);
         $(timespan).html(time);

        if(type == "system")
        {
             
        }
        else if(type == "weather")
        {
             var unit = 'F';
             if(weather.celsius)
             { unit = 'C'; }
             $(temperaturespan).html("TODAY'S MIN:<br /><span style='margin-right:10px;'>" + weather.low + "<sup>o</sup>" + unit + "</span><br />TODAY'S MAX:<br /><span style='margin-right:10px;'>" + weather.high + "<sup>o</sup>" + unit + "</span>");

              $(weatherspan).html(weather.condition);	
        }else if(type == "battery")
        {
             $(battspan).html("IT'S AT<br />" + batteryPercent + "<br />PERCENT<br />....!");
        }else if(type == "music")
        {
             if(isplaying)
             {
                  $(artistnsongspan).html(artist + '<br />' + title);
                  $(playbtn).removeClass('fa-play');
                  $(playbtn).addClass('fa-pause');

                  $(playbtn).unbind('click').on('click', function () {
                           window.location = 'xeninfo:playpause';
                           $(playbtn).removeClass('fa-pause');
                           $(playbtn).addClass('fa-play');
                   });

                   $(forwardbtn).unbind('click').on('click', function () {
                            window.location = 'xeninfo:nexttrack';
                   });

                   $(backwardbtn).unbind('click').on('click', function () {
                           window.location = 'xeninfo:prevtrack';
                   });
             }
             else
             {
                  $(playbtn).removeClass('fa-pause');
                  $(playbtn).addClass('fa-play');

                  $(playbtn).unbind('click').on('click', function () {
                           window.location = 'xeninfo:playpause';
                           $(playbtn).removeClass('fa-play');
                           $(playbtn).addClass('fa-pause');
                   });

                   $(forwardbtn).unbind('click').on('click', function () {
                           window.location = 'xeninfo:nexttrack';
                   });

                   $(backwardbtn).unbind('click').on('click', function () {
                           window.location = 'xeninfo:prevtrack';
                   });
             }
        }
}

